# [3D] Flip Hover Effects, Book Of Congratulations  from the game

A Pen created on CodePen.

Original URL: [https://codepen.io/rikanutyy/pen/PEJBxX](https://codepen.io/rikanutyy/pen/PEJBxX).

Book Of Congratulations  from the game

description:
The congratulatory card prepared by Sarah for her father Joel on his birthday, she forgets to give before the flash KCI.

#game #last_of_us #joel #sarah #congratulation  #book

ru: Открытка - поздравительная карточка, приготовленная Сарой для своего отца Джоэла на его день рождения, которую она забывает подарить до вспышки КЦИ.